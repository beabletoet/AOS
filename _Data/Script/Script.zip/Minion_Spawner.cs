﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Minion_Spawner : StatClass
{
    //스폰 대상
    public GameObject MeleeMinion;
    public GameObject CasterMinion;
    public GameObject SiegeMinion;
    public GameObject SuperMinion;

    //스폰 위치
    private Vector3 TopSpawnPointV;
    private Vector3 MidSpawnPointV;
    private Vector3 BottomSpawnPointV;
    public GameObject TopSpawnPoint;
    public GameObject MidSpawnPoint;
    public GameObject BottomSpawnPoint;

    private Stats stats;
    private float SpawnCycleTime = 30;

    private int WaveCount = 0;

    void Awake()
    {
        stats = new Stats();
        stats.first_Create_Time = 65;
        stats.Respawn_Time = 30;
        //SetJson("Minion_Warrior");
    }

    // Use this for initialization
    void Start()
    {
        TopSpawnPointV = TopSpawnPoint.transform.position;
        MidSpawnPointV = MidSpawnPoint.transform.position;
        BottomSpawnPointV = BottomSpawnPoint.transform.position;
    }

    void Spawn_MinionMelee(Vector3 position)
    {
        GameObject MinionMelee = Minion_ObjectPool.current.GetPooledMelee();

        if (MinionMelee == null) return;

        MinionMelee.transform.position = position;
        MinionMelee.SetActive(true);
    }

    IEnumerator Wave()
    {
        yield return new WaitForSeconds(stats.first_Create_Time);
        while(true)
        {
            yield return new WaitForSeconds(stats.Respawn_Time);
            Spawn_MinionMelee(TopSpawnPointV);
            Spawn_MinionMelee(MidSpawnPointV);
            Spawn_MinionMelee(BottomSpawnPointV);
        }

    }
    //private void OnGUI()
    //{
    //    if (GUI.Button(new Rect(450, 50, 70, 40), "Melee"))
    //    {
    //        Spawn_MinionMeleeTop(TopSpawnPointV);

    //    }
    //}
}