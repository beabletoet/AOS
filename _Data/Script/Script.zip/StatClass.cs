﻿using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Reflection;

public class StatClass : MonoBehaviour
{
    /// <summary>
    /// 캐릭터 스텟, Json, 몬스터는 에셋받고나서 공속,이속등 세팅
    /// </summary>
    public class Stats : MonoBehaviour
    {
        public int Level = 0;
        public int Exp = 0;
        public float Hp = 0;
        public float Hp_Restore_Time = 0;
        public float Mp = 0;
        public float Mp_Restore_Time = 0;
        public float Attack_Damage = 0;
        public float Ability_Power = 0;
        public float Attack_Speed = 0;
        public float Attack_Def = 0;
        public float Ability_Def = 0;
        public float CoolTime_Decrease = 0;
        public float Critical_Percentage = 0;
        public float Move_Speed = 0;
        public float Attack_Range = 0;
        public int Gold = 0;
        public float first_Create_Time = 0;
        public float Respawn_Time = 0;
        public float Exp_Increase = 0;

    }

    private static StatClass _instance;
    public static StatClass instane
    {
        get
        {
            if(_instance == null)
            {
                _instance = FindObjectOfType(typeof(StatClass)) as StatClass;
            }
            return _instance;
        }
    }
  
    ///<summary>
    ///Json에서 해당 오브젝트를 찾아, 참조할 스탯 클래스 )
    ///<para> NAME_LIST </para>
    ///<para>  Jungle_Frog, Jungle_Frog2, Jungle_Blue, Jungle_Blue2, Jungle_BWolf, Jungle_BWolf2 , Jungle_SWolf</para>
    ///<para>Jungle_SWolf2, Jungle_BKalnal, Jungle_BKalnal2, Jungle_SKalnal, Jungle_SKalnal2, Jungle_BGolem2</para>
    ///<para>Jungle_SGolem, Jungle_Crab, Jungle_Red, Jungle_Red2, Jungle_Dragon1, Jungle_Dragon2, Jungle_Dragon3</para>
    ///<para>Jungle_Dragon4, Jungle_ElderDragon, Jungle_Baron,  Minion_Warrior,  Minion_Magician  Minion_Super, Minion_Siege</para>
    ///</summary>
    protected Stats SetJson(string name, ref Stats stats)
    {
        //Stats stats = new Stats();

        string json = System.IO.File.ReadAllText(Application.dataPath + "/Json/AOS_Stats.json");
        JObject parse = JObject.Parse(json);

        stats.Level = parse.SelectToken(name).SelectToken("Level").Value<int>();
        stats.Exp = parse.SelectToken(name).SelectToken("Exp").Value<int>();
        stats.Hp = parse.SelectToken(name).SelectToken("Hp").Value<float>();
        stats.Hp_Restore_Time = parse.SelectToken(name).SelectToken("Hp_Restore_Time").Value<float>();
        stats.Mp = parse.SelectToken(name).SelectToken("Mp").Value<float>();
        stats.Mp_Restore_Time = parse.SelectToken(name).SelectToken("Mp_Restore_Time").Value<float>();
        stats.Attack_Damage = parse.SelectToken(name).SelectToken("Attack_Damage").Value<float>();
        stats.Ability_Power = parse.SelectToken(name).SelectToken("Ability_Power").Value<float>();
        stats.Attack_Speed = parse.SelectToken(name).SelectToken("Attack_Speed").Value<float>();
        stats.Attack_Def = parse.SelectToken(name).SelectToken("Attack_Def").Value<float>();
        stats.Ability_Def = parse.SelectToken(name).SelectToken("Ability_Def").Value<float>();
        stats.CoolTime_Decrease = parse.SelectToken(name).SelectToken("CoolTime_Decrease").Value<float>();
        stats.Critical_Percentage = parse.SelectToken(name).SelectToken("Critical_Percentage").Value<float>();
        stats.Move_Speed = parse.SelectToken(name).SelectToken("Move_Speed").Value<float>();
        stats.Attack_Range = parse.SelectToken(name).SelectToken("Attack_Range").Value<float>();
        stats.first_Create_Time = parse.SelectToken(name).SelectToken("first_Create_Time").Value<float>();
        stats.Respawn_Time = parse.SelectToken(name).SelectToken("Respawn_Time").Value<float>();
        stats.Exp_Increase = parse.SelectToken(name).SelectToken("Exp_Increase").Value<float>();

        //foreach (JToken token in parse.SelectToken(name))
        //{
        //    var hp = parse.SelectToken(name).Children()["Hp"].Value<float>();
        //    print(hp);

        //}

        return stats;
    }
}

