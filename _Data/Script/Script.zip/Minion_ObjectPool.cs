﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Minion_ObjectPool : MonoBehaviour {

    public static Minion_ObjectPool current; //모든 클래스에서 직접 호출 가능

    //풀링할 오브젝트
    public GameObject Pool_MeleeMinion;
    public GameObject Pool_CasterMinion;
    public GameObject Pool_SiegeMinion;
    public GameObject Pool_SuperMinion;

    public GameObject Minion_Storage; //미니언들을 Minion_Storage 밑으로 생성

    //풀링 개수
    public int PoolAmount_Melee = 30;
    public int PoolAmount_Caster = 30;
    public int PoolAmount_Siege = 10;
    public int PoolAmount_Super = 30;

    //리스트
    public List<GameObject> Pool_MeleeMinionList;
    public List<GameObject> Pool_CasterMinionList;
    public List<GameObject> Pool_SiegeMinionList;
    public List<GameObject> Pool_SuperMinionList;

    private void Awake()
    {
        //static으로 선언한 Minion_ObjectPool current에 접근
        current = this;
    }

    // Use this for initialization
    void Start () {
        Pool_MeleeMinionList = new List<GameObject>();
        Pool_CasterMinionList = new List<GameObject>();
        Pool_SiegeMinionList = new List<GameObject>();
        Pool_SuperMinionList = new List<GameObject>();

        for(int i = 0; i < PoolAmount_Melee; i++)
        {
            GameObject MeleeM = (GameObject)Instantiate(Pool_MeleeMinion);
            MeleeM.transform.parent = Minion_Storage.transform;

            MeleeM.SetActive(false);
            Pool_MeleeMinionList.Add(MeleeM);
        }

        for (int i = 0; i < PoolAmount_Caster; i++)
        {
            GameObject CasterM = (GameObject)Instantiate(Pool_CasterMinion);
            CasterM.transform.parent = Minion_Storage.transform;

            CasterM.SetActive(false);
            Pool_CasterMinionList.Add(CasterM);
        }
        for (int i = 0; i < PoolAmount_Siege; i++)
        {
            GameObject SiegeM = (GameObject)Instantiate(Pool_SiegeMinion);
            SiegeM.transform.parent = Minion_Storage.transform;

            SiegeM.SetActive(false);
            Pool_SiegeMinionList.Add(SiegeM);
        }
        for (int i = 0; i < PoolAmount_Super; i++)
        {
            GameObject SuperM = (GameObject)Instantiate(Pool_SuperMinion);
            SuperM.transform.parent = Minion_Storage.transform; // 자식을 부모 밑으로 생성

            SuperM.SetActive(false);
            Pool_SuperMinionList.Add(SuperM); //리스트에 추가
        }
    }

    public GameObject GetPooledMelee() //비활성화 되어있는 전사 미니언을 활성화 시킬 때 호출
    {
        for(int i = 0; i < Pool_MeleeMinionList.Count; i++)
        {
            //SetActive 가 false면 실행
            if(!Pool_MeleeMinionList[i].activeInHierarchy)
            {
                return Pool_MeleeMinionList[i];
            }
        }
        return null;
    }

    public GameObject GetPooledCaster() //비활성화 되어있는 전사 미니언을 활성화 시킬 때 호출
    {
        for (int i = 0; i < Pool_CasterMinionList.Count; i++)
        {
            //SetActive 가 false면 실행
            if (!Pool_CasterMinionList[i].activeInHierarchy)
            {
                return Pool_CasterMinionList[i];
            }
        }
        return null;
    }

    public GameObject GetPooledSiege() //비활성화 되어있는 전사 미니언을 활성화 시킬 때 호출
    {
        for (int i = 0; i < Pool_SiegeMinionList.Count; i++)
        {
            //SetActive 가 false면 실행
            if (!Pool_SiegeMinionList[i].activeInHierarchy)
            {
                return Pool_SiegeMinionList[i];
            }
        }
        return null;
    }

    public GameObject GetPooledSuper() //비활성화 되어있는 전사 미니언을 활성화 시킬 때 호출
    {
        for (int i = 0; i < Pool_SuperMinionList.Count; i++)
        {
            //SetActive 가 false면 실행
            if (!Pool_SuperMinionList[i].activeInHierarchy)
            {
                return Pool_SuperMinionList[i];
            }
        }
        return null;
    }
}
