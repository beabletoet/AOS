﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinionColider : MonoBehaviour
{

    private enum MinionType { Melee, Magic, Siege, Super }
    private enum Coliders { vaild, attack }
    [SerializeField]
    private Coliders colName;
    [SerializeField]
    private MinionType minionType;
    private float vaildRange = 15;
    //밀리&슈퍼 / 매직,시즈
    private float[] AttackRange = { 3, 5 };

    private MinionBehavior mi;

    SphereCollider col;
    private void Start()
    {
        col = GetComponent<SphereCollider>();
        mi = GetComponentInParent<MinionBehavior>();

        setMinion();
    }
    private void setMinion()
    {
        if (transform.parent.name.Contains("Super"))
        {
            minionType = MinionType.Super;
            setcol(0);
        }
        else if (transform.parent.name.Contains("Melee"))
        {
            minionType = MinionType.Melee;
            setcol(0);
        }
        else if (transform.parent.name.Contains("Magic"))
        {
            minionType = MinionType.Magic;
            setcol(1);
        }
        else if (transform.parent.name.Contains("Siege"))
        {
            minionType = MinionType.Siege;
            setcol(1);
        }
    }
    //0 = 밀리 1 = 원거리
    private void setcol(int attackType)
    {
        if (transform.name.Contains("Vaild"))
        {
            colName = Coliders.vaild;
            col.radius = vaildRange;
        }
        else if (transform.name.Contains("Attack"))
        {
            colName = Coliders.attack;
            col.radius = AttackRange[attackType];
        }

    }
    private void OnTriggerStay(Collider other)
    {   //14 = Red 15 = Blue
        if (other.gameObject.layer.Equals(14) || other.gameObject.layer.Equals(15))
        {
            if (gameObject.layer != other.gameObject.layer)
            {   
                if(colName.Equals(Coliders.vaild))
                {
                    if (other.transform.name.Contains("Minion") || other.transform.name.Contains("Champion"))
                    {   //타겟리스트에 없다면
                        if (!mi.FindTargetList(other.transform))
                            mi.addTargetList(other.transform);
                    }
                }
            }
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (colName.Equals(Coliders.vaild))
        {
            if (mi.FindTargetList(other.transform))
               mi.delTargetList(other.transform);
        }
    }
}
